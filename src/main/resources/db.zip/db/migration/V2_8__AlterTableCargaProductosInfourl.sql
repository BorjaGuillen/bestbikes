ALTER TABLE `bestbike_bd`.`cargaProductos` 
CHANGE COLUMN `infourl` `infourl` TEXT NOT NULL ;

